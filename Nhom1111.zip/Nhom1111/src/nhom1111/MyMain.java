package nhom1111;


public class MyMain {
	public static void main(String[] args) {
		new MyFrame("Dijkstra Demo");
	}
}
